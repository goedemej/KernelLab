﻿namespace KernelLab.Shared;

public static class SharedCounter
{
    public static int Value;
}
