﻿using KernelLab.Tasks.Core;

namespace KernelLab.Kernel;

/// <summary>
/// Priority-ordered ready queue.
/// Contains tasks in the READY state only.
/// The task at the front of the queue has the highest priority.
/// </summary>
public class ReadyQueue
{
    /// <summary>
    /// Head sentinel node.
    /// </summary>
    public BaseTask Head;

    /// <summary>
    /// Tail sentinel node.
    /// </summary>
    public BaseTask Tail;

    /// <summary>
    /// Initializes an empty queue using sentinel nodes.
    /// </summary>
    public void Init()
    {
        Head = new SentinelTask("HEAD");
        Tail = new SentinelTask("TAIL");

        Head.Next = Tail;
        Tail.Prev = Head;
    }

    /// <summary>
    /// Inserts a task into the queue while preserving
    /// descending priority order.
    ///
    /// Higher priority values are placed before lower
    /// priority values.
    ///
    /// Tasks with equal priority are inserted after
    /// existing tasks of the same priority, providing
    /// FIFO scheduling within a priority level.
    /// </summary>
    /// <param name="task">
    /// The task to enqueue.
    /// </param>
    public void Enqueue(BaseTask task)
    {
        BaseTask current = Head.Next;

        while (current != Tail &&
        task.Priority <= current.Priority)
        {
            current = current.Next;
        }

        BaseTask prev = current.Prev;

        task.Next = current;
        task.Prev = prev;

        prev.Next = task;
        current.Prev = task;
    }

    /// <summary>
    /// Removes and returns the highest-priority task.
    /// </summary>
    /// <returns>
    /// The task at the front of the queue, or null if
    /// the queue is empty.
    /// </returns>
    public BaseTask? Dequeue()
    {
        if (Head.Next == Tail)
            return null;

        BaseTask task = Head.Next;

        Head.Next = task.Next;
        task.Next.Prev = Head;

        task.Next = null;
        task.Prev = null;

        return task;
    }

    /// <summary>
    /// Returns the highest-priority task without removing it.
    /// </summary>
    /// <returns>
    /// The task at the front of the queue, or null if
    /// the queue is empty.
    /// </returns>
    public BaseTask? Peek()
    {
        return Head.Next == Tail
        ? null : Head.Next;
    }
}