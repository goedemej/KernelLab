﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Systems;

namespace KernelLab.Kernel;

public static class Kernel
{
    public static readonly ReadyQueue ReadyQueue = new();
    public static readonly MessageBus Bus = new();
    public static readonly TaskManager Tasks = new();
    public static BaseTask? CurrentTask;
    public static IdleTask IdleTask = new();

    public static void Init()
    {
        MessagePool.Init(32);

        ReadyQueue.Init();

        Tasks.Register(IdleTask);

        Scheduler.MakeReady(IdleTask);
    }
}