﻿using KernelLab.Diagnostics;
using KernelLab.States;
using KernelLab.Tasks.Core;

namespace KernelLab.Kernel;

/// <summary>
/// Fixed-priority preemptive scheduler.
/// </summary>
public static class Scheduler
{
    private static bool _rescheduleRequested;

    /// <summary>
    /// Makes a task runnable.
    /// </summary>
    public static void MakeReady(BaseTask task)
    {
        if (task.State == TaskState.Ready)
            return;

        ChangeState(task, TaskState.Ready);

        KernelTrace.Write(TraceType.Ready, task.TaskId);

        Kernel.ReadyQueue.Enqueue(task);

        _rescheduleRequested = true;
    }

    /// <summary>
    /// Executes one scheduler cycle.
    /// </summary>
    public static void Tick()
    {
        if (Kernel.CurrentTask == null)
            Dispatch();

        BaseTask? current = Kernel.CurrentTask;

        if (current == null)
            return;

        if (!current.Started)
        {
            current.Started = true;
            current.Execute();
        }
        else
        {
            current.Continue();
        }

        if (!_rescheduleRequested)
            return;

        _rescheduleRequested = false;

        if (Kernel.CurrentTask == null)
            Dispatch();
        else
            Reschedule();
    }

    /// <summary>
    /// Checks whether a higher-priority task should preempt.
    /// </summary>
    public static void Reschedule()
    {
        BaseTask? current = Kernel.CurrentTask;
        BaseTask? next = Kernel.ReadyQueue.Peek();

        if (next == null)
            return;

        if (current == null)
        {
            Dispatch();
            return;
        }

        if (next.Priority <= current.Priority)
            return;

        current.State = TaskState.Ready;

        KernelTrace.Write(TraceType.Ready, current.TaskId);

        Kernel.ReadyQueue.Enqueue(current);

        Kernel.CurrentTask = null;

        Dispatch();
    }

    /// <summary>
    /// Dispatches the next task.
    /// </summary>
    private static void Dispatch()
    {
        BaseTask? next = Kernel.ReadyQueue.Dequeue();

        if (next == null)
            next = Kernel.IdleTask;

        ChangeState(next, TaskState.Running);

        Kernel.CurrentTask = next;

        KernelTrace.Write(TraceType.Dispatch, "Scheduler", next.TaskId);

        KernelTrace.Write(TraceType.Running, next.TaskId);
    }

    /// <summary>
    /// Voluntary CPU relinquish.
    /// </summary>
    public static void Yield()
    {
        BaseTask? current = Kernel.CurrentTask;

        if (current == null)
            return;

        KernelTrace.Write(TraceType.Yield, current.TaskId);

        ChangeState(current, TaskState.Ready);

        Kernel.ReadyQueue.Enqueue(current);

        Kernel.CurrentTask = null;

        _rescheduleRequested = true;
    }

    /// <summary>
    /// Put current task in waiting state.
    /// </summary>
    public static void WaitCurrent()
    {
        BaseTask? current = Kernel.CurrentTask;

        if (current == null)
            return;

        KernelTrace.Write(TraceType.Waiting, current.TaskId);

        ChangeState(current, TaskState.Waiting);

        Kernel.CurrentTask = null;

        _rescheduleRequested = true;
    }

    /// <summary>
    /// Block current task.
    /// </summary>
    public static void BlockCurrent()
    {
        BaseTask? current = Kernel.CurrentTask;

        if (current == null)
            return;

        KernelTrace.Write(TraceType.Blocked, current.TaskId);

        ChangeState(current, TaskState.Blocked);

        Kernel.CurrentTask = null;

        _rescheduleRequested = true;
    }

    /// <summary>
    /// Terminate current task.
    /// </summary>
    public static void ExitCurrent()
    {
        BaseTask? current = Kernel.CurrentTask;

        if (current == null)
            return;

        KernelTrace.Write(TraceType.Exit, current.TaskId);

        ChangeState(current, TaskState.Terminated);

        Kernel.CurrentTask = null;

        _rescheduleRequested = true;
    }

    private static void ChangeState(BaseTask task, TaskState newState)
    {
        TaskState oldState = task.State;

        if (oldState == newState)
            return;

        task.State = newState;

        KernelTrace.Write(TraceType.StateTransition,
            task.TaskId, "", $"{oldState} -> {newState}");
    }
}
