﻿using KernelLab.Kernel;
using KernelLab.Studies.Messaging;
using KernelLab.Studies.Scheduling;
using KernelLab.Studies.Synchronization;
using KernelLab.Study.Fundamentals;
using KernelLab.Study.Messaging;
using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;

namespace KernelLab;

public static class Program
{
    public static void Main()
    {
        var studies = new IStudyCase[]
        {
            new Study01_BasicDispatch(),
            new Study02_Yield(),
            new Study03_Priority(),
            new Study04_Preemption(),
            new Study05_Starvation(),
            new Study06_WaitWakeup(),
            new Study07_Blocking(),
            new Study08_StateTransitions(),
            new Study09_RequestReply(),
            new Study10_MultipleRequestReply(),
            new Study11_MultipleClients(),
            new Study12_ProducerConsumerQueue(),
            new Study13_Semaphore(),
            new Study14_BinarySemaphore(),
            new Study15_Mutex(),
            new Study16_CriticalSection(),
            new Study17_Deadlock(),
            new Study18_DeadlockPrevention(),
            new Study19_ResourceAllocation(),   
            new Study20_ProducerConsumer()
        };

        Console.WriteLine("================================");
        Console.WriteLine("UIOSPRO Study Launcher");
        Console.WriteLine("================================");
        Console.WriteLine();

        for (int i = 0; i < studies.Length; i++)
        {
            Console.WriteLine(
                $"{i + 1}. {studies[i].Name}");
        }

        Console.WriteLine();

        Console.Write("Select study: ");

        int choice = int.Parse(
            Console.ReadLine() ?? "1");

        IStudyCase study = studies[choice - 1];

        Console.WriteLine();
        Console.WriteLine($"Running: {study.Name}");
        Console.WriteLine();

        study.Run();

        TaskBuilder<LoggerTask>
             .Create(new LoggerTask())
             .StartImmediately()
             .Build();

        while (true)
        {
            Scheduler.Tick();
        }
    }
}
