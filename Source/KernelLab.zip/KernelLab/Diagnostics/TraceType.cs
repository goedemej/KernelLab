﻿namespace KernelLab.Diagnostics;

public enum TraceType
{
    StateTransition,

    Dispatch,

    Ready,
    Running,
    Waiting,
    Blocked,
    Yield,
    Exit,

    MessageSend,
    MessageReceive,
    MessageReply
}
