﻿namespace KernelLab.Diagnostics;

public static class KernelTrace
{
    public static event Action<KernelTraceEvent>? OnTrace;

    public static void Write(
    TraceType type,
    string source,
    string target = "",
    string details = "")
    {
        OnTrace?.Invoke(
        new KernelTraceEvent
        {
            Timestamp = DateTime.Now,
            Type = type,
            Source = source,
            Target = target,
            Details = details
        });
    }
}
