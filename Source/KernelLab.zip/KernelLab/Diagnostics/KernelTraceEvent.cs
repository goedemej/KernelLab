﻿namespace KernelLab.Diagnostics;

public sealed class KernelTraceEvent
{
    public DateTime Timestamp { get; init; }

    public TraceType Type { get; init; }

    public string Source { get; init; } = string.Empty;

    public string Target { get; init; } = string.Empty;

    public string Details { get; init; } = string.Empty;
}