﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Resources;

namespace KernelLab.Studies.Synchronization;

public sealed class Study19_ResourceAllocation : IStudyCase
{
    public string Name => "Resource Allocation";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<ResourceTask>
        .Create(new ResourceTask("TASK1"))
        .StartImmediately()
        .Build();

        TaskBuilder<ResourceTask>
       .Create(new ResourceTask("TASK2"))
       .StartImmediately()
       .Build();

        TaskBuilder<ResourceTask>
        .Create(new ResourceTask("TASK3"))
        .StartImmediately()
        .Build();
    }
}
