﻿using KernelLab.Kernel;
using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Consumers;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Producers;

public sealed class Study20_ProducerConsumer : IStudyCase
{
    public string Name => "Producer/Consumer with Semaphore";

    public void Run()
    {
        Kernel.Init();

        TaskBuilder<ConsumerTask1>
       .Create(new ConsumerTask1())
       .StartImmediately()
       .Build();

        TaskBuilder<ProducerTask1>
       .Create(new ProducerTask1("PRODUCER1", "Job A"))
       .StartImmediately()
       .Build();

        TaskBuilder<ProducerTask1>
      .Create(new ProducerTask1("PRODUCER2", "Job B"))
      .StartImmediately()
      .Build();

    }
}