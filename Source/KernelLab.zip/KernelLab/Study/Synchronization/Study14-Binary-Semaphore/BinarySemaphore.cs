﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Synchronization;

public sealed class BinarySemaphore
{
    private bool _signaled;

    private readonly Queue<BaseTask> _waitingTasks = new();

    public bool Wait(BaseTask task)
    {
        if (_signaled)
        {
            _signaled = false;

            return true;
        }

        _waitingTasks.Enqueue(task);

        return false;
    }

    public void Signal()
    {
        _signaled = true;

        if (_waitingTasks.Count > 0)
        {
            BaseTask task =
                _waitingTasks.Dequeue();

            Scheduler.MakeReady(task);
        }
    }
}
