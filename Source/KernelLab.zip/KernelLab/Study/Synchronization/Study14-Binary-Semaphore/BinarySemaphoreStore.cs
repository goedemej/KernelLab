﻿namespace KernelLab.Synchronization;

public static class BinarySemaphoreStore
{
    public static readonly BinarySemaphore Event = new();
}
