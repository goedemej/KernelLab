﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Synchronization;

namespace KernelLab.Studies.Synchronization;

public sealed class Study14_BinarySemaphore : IStudyCase
{
    public string Name => "Binary Semaphore";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<ConsumerTask>
        .Create(new ConsumerTask())
        .StartImmediately()
        .Build();

        TaskBuilder<ProducerTask>
       .Create(new ProducerTask())
        .StartImmediately()
        .Build();
    }
}
