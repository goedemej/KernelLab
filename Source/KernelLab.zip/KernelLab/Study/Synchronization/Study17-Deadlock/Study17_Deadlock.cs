﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Synchronization;

namespace KernelLab.Studies.Synchronization;

public sealed class Study17_Deadlock : IStudyCase
{
    public string Name => "Deadlock";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<DeadlockTask>
         .Create(new DeadlockTask("TASK1", lockAFirst: true))
         .StartImmediately()
         .Build();

        TaskBuilder<DeadlockTask>
         .Create(new DeadlockTask("TASK2", lockAFirst: false))
         .StartImmediately()
         .Build();
    }
}