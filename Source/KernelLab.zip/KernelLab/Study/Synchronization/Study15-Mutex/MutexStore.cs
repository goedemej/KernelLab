﻿namespace KernelLab.Synchronization;

public static class MutexStore
{
    public static readonly SimpleMutex Resource = new();

    public static readonly SimpleMutex MutexA = new();

    public static readonly SimpleMutex MutexB = new();
}
