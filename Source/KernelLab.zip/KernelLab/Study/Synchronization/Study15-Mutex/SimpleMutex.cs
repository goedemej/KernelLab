﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Synchronization;

public sealed class SimpleMutex
{
    private BaseTask? _owner;

    private readonly Queue<BaseTask> _waitingTasks = new();

    public bool Lock(BaseTask task)
    {
        if (_owner == null)
        {
            _owner = task;

            return true;
        }

        _waitingTasks.Enqueue(task);

        return false;
    }

    public void Unlock(BaseTask task)
    {
        if (_owner != task)
        {
            throw new InvalidOperationException(
                $"Task '{task.TaskId}' does not own the mutex.");
        }

        _owner = null;

        if (_waitingTasks.Count > 0)
        {
            BaseTask next = _waitingTasks.Dequeue();

            Scheduler.MakeReady(next);
        }
    }

    public string? Owner => _owner?.TaskId;
}