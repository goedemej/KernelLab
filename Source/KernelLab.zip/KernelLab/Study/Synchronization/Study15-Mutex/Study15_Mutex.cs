﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Synchronization;

namespace KernelLab.Studies.Synchronization;

public sealed class Study15_Mutex : IStudyCase
{
    public string Name => "Mutex";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<MutexTask>
         .Create(new MutexTask("TASK1"))
         .StartImmediately()
         .Build();

        TaskBuilder<MutexTask>
         .Create(new MutexTask("TASK2"))
         .StartImmediately()
         .Build();
    }
}