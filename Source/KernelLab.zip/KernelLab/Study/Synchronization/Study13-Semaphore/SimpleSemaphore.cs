﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Synchronization;

public sealed class SimpleSemaphore
{
    private int _count;

    private readonly Queue<BaseTask> _waitingTasks = new();

    public SimpleSemaphore(int initialCount)
    {
        _count = initialCount;
    }

    public bool Acquire(BaseTask task)
    {
        if (_count > 0)
        {
            _count--;

            return true;
        }

        _waitingTasks.Enqueue(task);

        return false;
    }

    public void Release()
    {
        _count++;

        if (_waitingTasks.Count > 0)
        {
            BaseTask task = _waitingTasks.Dequeue();

            Scheduler.MakeReady(task);
        }
    }
}
