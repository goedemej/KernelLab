﻿namespace KernelLab.Synchronization;

public static class SemaphoreStore
{
    public static readonly SimpleSemaphore Resource = new(1);
}
