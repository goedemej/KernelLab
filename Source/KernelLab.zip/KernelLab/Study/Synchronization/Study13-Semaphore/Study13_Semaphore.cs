﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Synchronization;

namespace KernelLab.Studies.Synchronization;

public sealed class Study13_Semaphore : IStudyCase
{
    public string Name => "Semaphore";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<SemaphoreTask>
         .Create(new SemaphoreTask("TASK1"))
         .StartImmediately()
         .Build();
            
        TaskBuilder<SemaphoreTask>
         .Create(new SemaphoreTask("TASK2"))
         .StartImmediately()
         .Build();
    }
}