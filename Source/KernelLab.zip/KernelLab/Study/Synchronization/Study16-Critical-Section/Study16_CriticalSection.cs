﻿using KernelLab.Shared;
using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Synchronization;

namespace KernelLab.Studies.Synchronization;

public sealed class Study16_CriticalSection : IStudyCase
{
    public string Name => "Critical Section";

    public void Run()
    {
        Kernel.Kernel.Init();

        SharedCounter.Value = 0;

        TaskBuilder<CounterTask>
         .Create(new CounterTask("TASK1"))
         .StartImmediately()
         .Build();

        TaskBuilder<CounterTask>
         .Create(new CounterTask("TASK2"))
         .StartImmediately()
         .Build();

    }
}