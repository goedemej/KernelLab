﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Synchronization;

namespace KernelLab.Studies.Synchronization;

public sealed class Study18_DeadlockPrevention : IStudyCase
{
    public string Name => "Deadlock Prevention";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<DeadlockPreventionTask>
         .Create(new DeadlockPreventionTask("TASK1"))
         .StartImmediately()
         .Build();

        TaskBuilder<DeadlockPreventionTask>
         .Create(new DeadlockPreventionTask("TASK2"))
         .StartImmediately()
         .Build();
    }
}