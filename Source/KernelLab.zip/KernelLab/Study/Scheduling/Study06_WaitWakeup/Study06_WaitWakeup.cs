﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Scheduling;

namespace KernelLab.Studies.Scheduling;

public sealed class Study06_WaitWakeup : IStudyCase
{
    public string Name => "Wait and Wakeup";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<WaitingTask>
          .Create(new WaitingTask())
          .StartImmediately()
          .Build();

        TaskBuilder<SignalerTask>
          .Create(new SignalerTask("WAITER"))
          .StartImmediately()
          .Build();
    }
}
