﻿using KernelLab.Tasks.Management;
using KernelLab.Tasks.System;
using KernelLab.Tasks.Tests.Fundamentals;
using KernelLab.Tasks.Tests.Priorities;

namespace KernelLab.Study.Scheduling;

public sealed class Study04_Preemption : IStudyCase
{
    public string Name => "Preemption";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<CounterTask>
          .Create(new CounterTask())
          .StartImmediately()
          .Build();

        Kernel.Kernel.Tasks.Register(
            new HighPriorityTask());

        TaskBuilder<TimerTask>
           .Create(new TimerTask(
               targetTaskId: "HIGH",
               triggerTick: 5))
           .StartImmediately()
           .Build();
    }
}