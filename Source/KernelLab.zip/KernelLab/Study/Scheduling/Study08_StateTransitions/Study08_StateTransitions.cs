﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Scheduling;

namespace KernelLab.Studies.Scheduling;

public sealed class Study08_StateTransitions : IStudyCase
{
    public string Name => "State Transitions";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<TransitionTask>
        .Create(new TransitionTask())
        .StartImmediately()
        .Build();

        TaskBuilder<WakerTask>
        .Create(new WakerTask("TRANSITION"))
        .StartImmediately()
        .Build();
    }
}