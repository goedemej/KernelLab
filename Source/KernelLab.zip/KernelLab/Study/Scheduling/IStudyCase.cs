﻿namespace KernelLab.Study.Scheduling;

public interface IStudyCase
{
    string Name { get; }

    void Run();
}
