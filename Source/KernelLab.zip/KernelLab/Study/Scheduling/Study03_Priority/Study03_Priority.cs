﻿using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Priorities;

namespace KernelLab.Study.Scheduling;

public sealed class Study03_Priority : IStudyCase
{
    public string Name => "Priority Scheduling";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<LowPriorityTask>
          .Create(new LowPriorityTask())
          .StartImmediately()
          .Build();

        TaskBuilder<HighPriorityTask>
          .Create(new HighPriorityTask())
          .StartImmediately()
          .Build();
    }
}   
   