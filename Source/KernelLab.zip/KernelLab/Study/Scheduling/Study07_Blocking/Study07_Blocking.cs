﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Scheduling;

namespace KernelLab.Studies.Scheduling;

public sealed class Study07_Blocking
: IStudyCase
{
    public string Name => "Blocking";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<BlockingTask>
         .Create(new BlockingTask())
         .StartImmediately()
         .Build();

        TaskBuilder<WorkerTask>
         .Create(new WorkerTask("CLIENT"))
         .StartImmediately()
         .Build();
    }
}