﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Priorities;

namespace KernelLab.Studies.Scheduling;

public sealed class Study05_Starvation : IStudyCase
{
    public string Name => "Starvation";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<HighPriorityTask>
          .Create(new HighPriorityTask())
          .StartImmediately()
          .Build();

        TaskBuilder<LowPriorityTask>
         .Create(new LowPriorityTask())
         .StartImmediately()
         .Build();
    }
}