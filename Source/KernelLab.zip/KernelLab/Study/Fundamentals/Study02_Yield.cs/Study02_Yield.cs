﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Fundamentals;

namespace KernelLab.Study.Fundamentals;

public sealed class Study02_Yield : IStudyCase
{
    public string Name => "Yield";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<CounterTask1>
           .Create(new CounterTask1())
           .StartImmediately()
           .Build();

        TaskBuilder<CounterTask2>
           .Create(new CounterTask2())
           .StartImmediately()
           .Build();
    }
}