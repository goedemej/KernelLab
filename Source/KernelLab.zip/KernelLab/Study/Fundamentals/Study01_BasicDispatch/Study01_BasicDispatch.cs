﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Fundamentals;

namespace KernelLab.Study.Fundamentals;

public sealed class Study01_BasicDispatch : IStudyCase
{
    public string Name => "Basic Dispatch";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<CounterTask>
            .Create(new CounterTask())
            .StartImmediately()
            .Build();
    }
}
