﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Clients;
using KernelLab.Tasks.Tests.Workers;

namespace KernelLab.Study.Messaging;

public sealed class Study09_RequestReply : IStudyCase
{
    public string Name => "Request/Reply Messaging";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<ClientTask>
            .Create(new ClientTask())
            .StartImmediately()
            .Build();

        TaskBuilder<WorkerTask>
             .Create(new WorkerTask())
             .StartImmediately()
             .Build();
    }
}
