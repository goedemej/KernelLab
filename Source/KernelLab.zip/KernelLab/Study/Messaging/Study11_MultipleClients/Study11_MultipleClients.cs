﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Clients;
using KernelLab.Tasks.Tests.Workers;

namespace KernelLab.Study.Messaging;

public sealed class Study11_MultipleClients : IStudyCase
{
    public string Name => "Multiple Clients";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<Worker2Task>
            .Create(new Worker2Task())
            .StartImmediately()
            .Build();

        TaskBuilder<Client2Task>
            .Create(new Client2Task("CLIENT2", "Job A"))
            .StartImmediately()
            .Build();


        TaskBuilder<Client2Task>
            .Create(new Client2Task("CLIENT3", "Job B"))    
            .StartImmediately()
            .Build();


        TaskBuilder<Client2Task>
            .Create(new Client2Task("CLIENT4", "Job C"))    
            .StartImmediately()
            .Build();
    }
}
