﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Clients;
using KernelLab.Tasks.Tests.Workers;

namespace KernelLab.Study.Messaging;

public class Study10_MultipleRequestReply : IStudyCase
{

    public string Name => "Multiple Request/Reply Messaging";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<Client1Task>
            .Create(new Client1Task())
            .StartImmediately()
            .Build();

        TaskBuilder<Worker1Task>
             .Create(new Worker1Task())
             .StartImmediately()
             .Build();
    }
}
