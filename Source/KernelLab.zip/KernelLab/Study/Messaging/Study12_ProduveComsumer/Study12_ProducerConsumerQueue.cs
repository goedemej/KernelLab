﻿using KernelLab.Study.Scheduling;
using KernelLab.Tasks.Consumers;
using KernelLab.Tasks.Management;
using KernelLab.Tasks.Tests.Producers;

namespace KernelLab.Studies.Messaging;

public sealed class Study12_ProducerConsumerQueue : IStudyCase
{
    public string Name => "Producer / Consumer Queue";

    public void Run()
    {
        Kernel.Kernel.Init();

        TaskBuilder<ConsumerTask>
           .Create(new ConsumerTask())
           .StartImmediately()
           .Build();

        TaskBuilder<ProducerTask>
            .Create(new ProducerTask("PRODUCER1", "Job A", "CONSUMER"))
            .StartImmediately()
            .Build();

        TaskBuilder<ProducerTask>
           .Create(new ProducerTask("PRODUCER2", "Job B", "CONSUMER"))
           .StartImmediately()
           .Build();

        TaskBuilder<ProducerTask>
           .Create(new ProducerTask("PRODUCER3", "Job C", "CONSUMER"))
           .StartImmediately()
           .Build();
    }
} 
    