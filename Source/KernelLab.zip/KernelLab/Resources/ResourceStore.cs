﻿namespace KernelLab.Resources;

public static class ResourceStore
{
    public static readonly ResourcePool Pool = new();
}
