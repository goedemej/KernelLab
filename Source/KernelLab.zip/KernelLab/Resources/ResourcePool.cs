﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Resources;

public sealed class ResourcePool
{
    private readonly Queue<string> _available = new();

    private readonly Queue<BaseTask> _waitingTasks = new();

    public ResourcePool()
    {
        _available.Enqueue("RESOURCE-1");
        _available.Enqueue("RESOURCE-2");
    }

    public string? Allocate(BaseTask task)
    {
        if (_available.Count == 0)
        {
            _waitingTasks.Enqueue(task);

            return null;
        }

        return _available.Dequeue();
    }

    public void Release(string resource)
    {
        _available.Enqueue(resource);

        if (_waitingTasks.Count > 0)
        {
            BaseTask task = _waitingTasks.Dequeue();

            Scheduler.MakeReady(task);
        }
    }
}