﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.System;

public sealed class TimerTask : BaseTask
{
    private int _ticks;

    private readonly string _targetTaskId;

    private readonly int _triggerTick;

    public TimerTask(
        string targetTaskId,
        int triggerTick = 5)
        : base("TIMER", priority: 10)
    {
        _targetTaskId = targetTaskId;
        _triggerTick = triggerTick;
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        _ticks++;

        Console.WriteLine($"Timer tick {_ticks}");

        if (_ticks == _triggerTick)
        {
            BaseTask? task = Kernel.Kernel.Tasks.Find(_targetTaskId);

            if (task != null)
            {
                Console.WriteLine($"Timer waking {_targetTaskId}");

                Scheduler.MakeReady(task);
            }

            Exit();
            return;
        }

        Yield();
    }
}