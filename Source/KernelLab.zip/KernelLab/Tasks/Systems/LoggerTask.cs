﻿using KernelLab.Diagnostics;
using KernelLab.Tasks.Core;

public sealed class LoggerTask : BaseTask
{
    public LoggerTask()
        : base("LOGGER", priority: 1)
    {
        KernelTrace.OnTrace += HandleTrace;
    }

    private void HandleTrace(KernelTraceEvent trace)
    {
        Console.WriteLine(
            $"[{trace.Timestamp:HH:mm:ss.fff}] " +
            $"{trace.Type,-15} " +
            $"{trace.Source,-20} " +
            $"{trace.Target,-10} " +
            $"{trace.Details}");
    }

    public override void Execute()
    {
        Wait();
    }

    public override void Continue()
    {
        Wait();
    }
}