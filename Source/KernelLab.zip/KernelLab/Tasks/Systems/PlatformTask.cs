﻿using KernelLab.Diagnostics;
using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace UIOS.Tasks.System;

public sealed class PlatformTask : BaseTask
{
    private int _events;

    public PlatformTask()
        : base("PLATFORM", priority: 1)
    {
        KernelTrace.OnTrace += _ =>
        {
            _events++;

            Scheduler.MakeReady(this);
        };
    }

    public override void Execute()
    {
        Display();

        Wait();
    }

    public override void Continue()
    {
        Display();

        Wait();
    }

    private void Display()
    {
        Console.WriteLine();
        Console.WriteLine("========== PLATFORM ==========");
        Console.WriteLine(
            $"Current : {Kernel.CurrentTask?.TaskId}");

        Console.WriteLine(
            $"Trace events : {_events}");

        Console.WriteLine(
            $"Ready tasks : {CountReadyTasks()}");

        Console.WriteLine("==============================");
    }

    private static int CountReadyTasks()
    {
        int count = 0;

        BaseTask current =
            Kernel.ReadyQueue.Head.Next;

        while (current != Kernel.ReadyQueue.Tail)
        {
            count++;
            current = current.Next;
        }

        return count;
    }
}
