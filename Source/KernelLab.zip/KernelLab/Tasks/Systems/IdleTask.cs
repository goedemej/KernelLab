﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Systems;

/// <summary>
/// Runs when no other task is ready.
/// </summary>
public sealed class IdleTask : BaseTask
{
    public IdleTask()
        : base(taskId: "IDLE", priority: int.MinValue)
    {
    }

    public override void Execute()
    {
        Idle();
    }

    public override void Continue()
    {
        Idle();
    }

    private static void Idle()
    {
        // Optional:
        // CPU halt
        // power saving
        // statistics collection

        Thread.Sleep(1);
    }
}
