﻿using KernelLab.Kernel;
using KernelLab.States;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Management;

public sealed class TaskManager
{
    private readonly Dictionary<string, BaseTask> _tasks = new();

    public IReadOnlyDictionary<string, BaseTask> Tasks => _tasks;

    public void Register(BaseTask task)
    {
        if (_tasks.ContainsKey(task.TaskId))
        {
            throw new InvalidOperationException(
            $"Task '{task.TaskId}' already exists.");
        }

        _tasks.Add(task.TaskId, task);
    }

    public T Create<T>(T task)
    where T : BaseTask
    {
        Register(task);

        Scheduler.MakeReady(task);

        return task;
    }

    public BaseTask? Find(string taskId)
    {
        _tasks.TryGetValue(taskId, out BaseTask? task);

        return task;
    }

    public void Start(string taskId)
    {
        BaseTask? task = Find(taskId);

        if (task == null)
            return;

        Scheduler.MakeReady(task);
    }

    public void Stop(string taskId)
    {
        BaseTask? task = Find(taskId);

        if (task == null)
            return;

        task.State = TaskState.Terminated;
    }

    public void Remove(string taskId)
    {
        _tasks.Remove(taskId);
    }
}
