﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Management;

public sealed class TaskBuilder<T>
    where T : BaseTask
{
    private readonly T _task;

    private bool _autoStart;

    private TaskBuilder(T task)
    {
        _task = task;
    }

    public static TaskBuilder<T> Create(T task)
    {
        return new(task);
    }

    public TaskBuilder<T> WithPriority(int priority)
    {
        _task.Priority = priority;
        return this;
    }

    public TaskBuilder<T> StartImmediately()
    {
        _autoStart = true;
        return this;
    }

    public T Build()
    {
        Kernel.Kernel.Tasks.Register(_task);

        if (_autoStart)
            Scheduler.MakeReady(_task);

        return _task;
    }
}