﻿using KernelLab.Queues;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Consumers;

public sealed class ConsumerTask1 : BaseTask
{
    private int _processedJobs;

    public ConsumerTask1() : base("CONSUMER", priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        while (WorkQueue.TryDequeue(
        out string job))
        {
            Console.WriteLine($"Processing: {job}");

            _processedJobs++;

            if (_processedJobs >= 2)
            {
                Exit();

                return;
            }
        }

        if (!ProducerConsumerSemaphore
        .Signal
        .Wait(this))
        {
            Console.WriteLine("CONSUMER waiting");

            Wait();

            return;
        }

        Yield();
    }
}
 