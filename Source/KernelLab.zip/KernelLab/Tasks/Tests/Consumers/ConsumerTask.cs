﻿using KernelLab.Tasks.Core;
using KernelLab.Tasks.Tests.Queues;

namespace KernelLab.Tasks.Consumers;

public sealed class ConsumerTask : BaseTask
{
    public ConsumerTask() : base("CONSUMER", priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        if (!WorkQueue.TryDequeue(out string item))
        {
            Wait();

            return;
        }

        Console.WriteLine($"Processing: {item}");

        Yield();
    }
}