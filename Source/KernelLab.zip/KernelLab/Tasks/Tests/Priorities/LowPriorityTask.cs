﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Priorities;

public sealed class LowPriorityTask : BaseTask
{
    public LowPriorityTask()
        : base("LOW", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("LOW TASK RUNNING");

        Exit();
    }

    public override void Continue()
    {
    }
}