﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Priorities;

public sealed class HighPriorityTask : BaseTask
{
    private int _count;

    public HighPriorityTask()
        : base("HIGH", priority: 50)
    {
    }

    public override void Execute()
    {
        Console.WriteLine(
            "HIGH task started");

        Continue();
    }

    public override void Continue()
    {
        _count++;

        Console.WriteLine( $"HIGH = {_count}");

        if (_count >= 20)
        {
            Console.WriteLine( "HIGH task finished");

            Exit();

            return;
        }

        Yield();
    }
}