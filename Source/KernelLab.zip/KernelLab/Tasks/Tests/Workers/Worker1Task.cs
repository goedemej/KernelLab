﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Workers;

public sealed class Worker1Task : BaseTask
{
    private int _processed = 0;

    public Worker1Task()
        : base("WORKER1", priority: 6)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        Message? request = Receive();

        if (request == null)
        {
            Wait();
            return;
        }

        Reply(
        request,
        MessageType.Response,
        $"Result for {request.Payload}");

        _processed++;

        if (_processed == 3)
        {
            Message complete = CreateMessage(
                request.SenderId,
                MessageType.Complete,
                "All jobs finished");

            Send(complete);

            _processed = 0;
        }

        MessagePool.Return(request);

        // Nog berichten?
        if (Messages.Count > 0)
            Yield();
        else
            Wait();
    }
}