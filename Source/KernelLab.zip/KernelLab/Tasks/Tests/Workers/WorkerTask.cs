﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Workers;

public sealed class WorkerTask : BaseTask
{
    public WorkerTask()
        : base("WORKER", priority: 5)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("Worker started");

        Continue();
    }

    public override void Continue()
    {
        Message? request = Receive();

        if (request == null)
        {
            Wait();

            return;
        }

        Console.WriteLine(
            $"Processing: {request.Payload}");

        Reply(
            request,
            MessageType.Response,
            $"Completed: {request.Payload}");

        MessagePool.Return(request);

        Wait();
    }
}
