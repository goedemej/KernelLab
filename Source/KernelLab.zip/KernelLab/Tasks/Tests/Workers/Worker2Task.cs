﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Workers;

public sealed class Worker2Task : BaseTask
{
    public Worker2Task() : base("WORKER2", priority: 5)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        Message? request = Receive();

        if (request == null)
        {
            Wait();
            return;
        }

        Console.WriteLine(
            $"Processing: {request.Payload}");

        Reply(
            request,
            MessageType.Response,
            $"Completed: {request.Payload}");

        MessagePool.Return(request);

        Yield();
    }
}