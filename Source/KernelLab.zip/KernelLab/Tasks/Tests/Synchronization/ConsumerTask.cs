﻿using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Synchronization;

public sealed class ConsumerTask : BaseTask
{
    private bool _eventReceived;

    public ConsumerTask() : base("CONSUMER", priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        if (!_eventReceived)
        {
            if (!BinarySemaphoreStore.Event.Wait(this))
            {
                Console.WriteLine("CONSUMER waiting");

                Wait();

                return;
            }

            _eventReceived = true;
        }

        Console.WriteLine("CONSUMER resumed");

        Exit();
    }
}