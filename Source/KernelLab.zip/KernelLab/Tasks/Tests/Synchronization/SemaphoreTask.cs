﻿using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Synchronization;

public sealed class SemaphoreTask : BaseTask
{
    private bool _hasSemaphore;

    public SemaphoreTask(string taskId) : base(taskId, priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        if (!_hasSemaphore)
        {
            if (!SemaphoreStore.Resource.Acquire(this))
            {
                Console.WriteLine($"{TaskId} waiting for semaphore");

                Wait();

                return;
            }

            _hasSemaphore = true;

            Console.WriteLine($"{TaskId} acquired semaphore");

            Yield();

            return;
        }

        Console.WriteLine($"{TaskId} releasing semaphore");

        SemaphoreStore.Resource.Release();

        Exit();
    }
}