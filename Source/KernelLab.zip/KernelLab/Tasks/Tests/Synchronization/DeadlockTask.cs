﻿using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Synchronization;

public sealed class DeadlockTask : BaseTask
{
    private readonly bool _lockAFirst;

    private int _step;

    public DeadlockTask(string taskId, bool lockAFirst) : base(taskId, priority: 10)
    {
        _lockAFirst = lockAFirst;
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        switch (_step)
        {
            case 0:
                {
                    if (_lockAFirst)
                    {
                        MutexStore.MutexA.Lock(this);

                        Console.WriteLine($"{TaskId} acquired MUTEX_A");
                    }
                    else
                    {
                        MutexStore.MutexB.Lock(this);

                        Console.WriteLine($"{TaskId} acquired MUTEX_B");
                    }

                    _step = 1;

                    Yield();

                    return;
                }

            case 1:
                {
                    bool acquired =
                        _lockAFirst
                            ? MutexStore.MutexB.Lock(this)
                            : MutexStore.MutexA.Lock(this);

                    if (!acquired)
                    {
                        Console.WriteLine($"{TaskId} waiting for second mutex");

                        Wait();

                        return;
                    }

                    Console.WriteLine($"{TaskId} acquired second mutex");

                    Exit();

                    return;
                }
        }
    }
}