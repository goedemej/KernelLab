﻿using KernelLab.Shared;
using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Synchronization;

public sealed class CounterTask : BaseTask
{
    private bool _ownsMutex;

    public CounterTask(string taskId) : base(taskId, priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        if (!_ownsMutex)
        {
            if (!MutexStore.Resource.Lock(this))
            {
                Console.WriteLine($"{TaskId} waiting for critical section");

                Wait();

                return;
            }

            _ownsMutex = true;

            Console.WriteLine($"{TaskId} entered critical section");

            int current =
                SharedCounter.Value;

            SharedCounter.Value =
                current + 1;

            Console.WriteLine($"Counter = {SharedCounter.Value}");

            Yield();

            return;
        }

        Console.WriteLine($"{TaskId} leaving critical section");

        MutexStore.Resource.Unlock(this);

        Exit();
    }
}