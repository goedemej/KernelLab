﻿using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Synchronization;

public sealed class MutexTask : BaseTask
{
    private bool _ownsMutex;

    public MutexTask(string taskId) : base(taskId, priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        if (!_ownsMutex)
        {
            if (!MutexStore.Resource.Lock(this))
            {
                Console.WriteLine($"{TaskId} waiting for mutex");

                Wait();

                return;
            }

            _ownsMutex = true;

            Console.WriteLine(
                $"{TaskId} acquired mutex");

            Console.WriteLine($"Owner = {MutexStore.Resource.Owner}");

            Yield();

            return;
        }

        Console.WriteLine($"{TaskId} releasing mutex");

        MutexStore.Resource.Unlock(this);

        Exit();
    }
}