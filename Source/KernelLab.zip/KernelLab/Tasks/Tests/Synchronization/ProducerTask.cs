﻿using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Synchronization;

public sealed class ProducerTask : BaseTask
{
    public ProducerTask() : base("PRODUCER", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("PRODUCER signaling event");

        BinarySemaphoreStore.Event.Signal();

        Exit();
    }

    public override void Continue()
    {
    }
}
