﻿using KernelLab.Synchronization;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Synchronization;

public sealed class DeadlockPreventionTask : BaseTask
{
    private int _step;

    public DeadlockPreventionTask(string taskId) : base(taskId, priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        switch (_step)
        {
            case 0:
                {
                    if (!MutexStore.MutexA.Lock(this))
                    {
                        Console.WriteLine($"{TaskId} waiting for MUTEX_A");

                        Wait();

                        return;
                    }

                    Console.WriteLine($"{TaskId} acquired MUTEX_A");

                    _step = 1;

                    Yield();

                    return;
                }

            case 1:
                {
                    if (!MutexStore.MutexB.Lock(this))
                    {
                        Console.WriteLine($"{TaskId} waiting for MUTEX_B");

                        Wait();

                        return;
                    }

                    Console.WriteLine($"{TaskId} acquired MUTEX_B");

                    _step = 2;

                    Yield();

                    return;
                }

            case 2:
                {
                    Console.WriteLine($"{TaskId} completed work");

                    MutexStore.MutexB.Unlock(this);

                    MutexStore.MutexA.Unlock(this);

                    Exit();

                    return;
                }
        }
    }
}