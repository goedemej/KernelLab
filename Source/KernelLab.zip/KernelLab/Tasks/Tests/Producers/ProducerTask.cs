﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;
using KernelLab.Tasks.Tests.Queues;

namespace KernelLab.Tasks.Tests.Producers;

public sealed class ProducerTask : BaseTask
{
    private readonly string _job;

    private readonly string _consumerId;

    public ProducerTask(
    string taskId,
    string job,
    string consumerId)
    : base(taskId, priority: 10)
    {
        _job = job;
        _consumerId = consumerId;
    }

    public override void Execute()
    {
        Console.WriteLine($"{TaskId} produced {_job}");

        WorkQueue.Enqueue(_job);

        BaseTask? consumer =
        Kernel.Kernel.Tasks.Find(_consumerId);

        if (consumer != null)
        {
            Scheduler.MakeReady(consumer);
        }

        Exit();
    }

    public override void Continue()
    {
    }
}
 