﻿using KernelLab.Queues;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Producers;

public sealed class ProducerTask1 : BaseTask
{
    private readonly string _job;

    public ProducerTask1(string taskId, string job) : base(taskId, priority: 10)
    {
        _job = job;
    }

    public override void Execute()
    {
        Console.WriteLine($"{TaskId} produced {_job}");

        WorkQueue.Enqueue(_job);

        ProducerConsumerSemaphore
            .Signal
            .Signal();

        Exit();
    }

    public override void Continue()
    {
    }
}