﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Clients;

public sealed class ClientTask : BaseTask
{
    public ClientTask() : base("CLIENT", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("Client started");

        Message request = CreateMessage(
        "WORKER",
        MessageType.Request,
        "Generate Report");

        SendAndWait(request);
    }

    public override void Continue()
    {
        Message? reply = Receive();

        if (reply == null)
            return;

        Console.WriteLine(
        $"Reply: {reply.Payload}");

        MessagePool.Return(reply);

        Exit();
    }
}