﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Clients;

public sealed class Client2Task : BaseTask
{
    private readonly string _job;

    public Client2Task(
        string taskId,
        string job)
        : base(taskId, priority: 11)
    {
        _job = job;
    }

    public override void Execute()
    {
        Console.WriteLine(
            $"{TaskId} started");

        SendAndWait(
            CreateMessage(
                "WORKER2",
                MessageType.Request,
                _job));
    }

    public override void Continue()
    {
        Message? reply = Receive();

        if (reply == null)
            return;

        Console.WriteLine(
            $"{TaskId} received: {reply.Payload}");

        MessagePool.Return(reply);

        Exit();
    }
}