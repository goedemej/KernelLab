﻿using KernelLab.Messaging;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Clients;

public sealed class Client1Task : BaseTask
{
    private readonly List<Message> _replies = new();

    public Client1Task()
        : base("CLIENT1", priority: 11)
    {
    }

    public override void Execute()
    {
        Send(CreateMessage(
        "WORKER1",
        MessageType.Request,
        "Job 1"));

        Send(CreateMessage(
        "WORKER1",
        MessageType.Request,
        "Job 2"));

        Send(CreateMessage(
        "WORKER1",
        MessageType.Request,
        "Job 3"));

        Wait();
    }

    public override void Continue()
    {
        while (Messages.Count > 0)
        {
            Message? msg = Receive();

            if (msg == null)
                break;

            if (msg.Type == MessageType.Response)
            {
                _replies.Add(msg);
                continue;
            }

            if (msg.Type == MessageType.Complete)
            {
                foreach (Message reply in _replies)
                {
                    MessagePool.Return(reply);
                }

                _replies.Clear();

                MessagePool.Return(msg);

                Wait();
                return;
            }

            MessagePool.Return(msg);
        }

        Wait();
    }
}
