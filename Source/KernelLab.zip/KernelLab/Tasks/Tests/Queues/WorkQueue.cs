﻿namespace KernelLab.Tasks.Tests.Queues;

public static class WorkQueue 
{
    private static readonly Queue<string> _queue = new();

    public static void Enqueue(string item)
    {
        _queue.Enqueue(item);
    }

    public static bool TryDequeue(out string item)
    {
        if (_queue.Count == 0)
        {
            item = string.Empty;

            return false;
        }

        item = _queue.Dequeue();

        return true;
    }

    public static int Count => _queue.Count;
}