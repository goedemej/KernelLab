﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Fundamentals;

public sealed class CounterTask : BaseTask
{
    private int _count;

    public CounterTask()
        : base("COUNTER", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine();
        Console.WriteLine("Counter started");

        Continue();
    }

    public override void Continue()
    {
        _count++;

        Console.WriteLine($"Count = {_count}");

        if (_count >= 10)
        {
            Console.WriteLine("Counter finished");
            Exit();
            return;
        }

        Yield();
    }
}