﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Fundamentals;

public sealed class CounterTask2 : BaseTask
{
    private int _count;

    public CounterTask2()
        : base("COUNTER2", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("Counter 2 started");

        Continue();
    }

    public override void Continue()
    {
        _count++;

        Console.WriteLine($"Counter 2 = {_count}");

        if (_count >= 10)
        {
            Console.WriteLine("Counter 2 finished");

            Exit();
            return;
        }

        Yield();
    }
}