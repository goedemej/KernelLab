﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Tests.Fundamentals;

public sealed class CounterTask1 : BaseTask
{
    private int _count;

    public CounterTask1()
        : base("COUNTER1", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine();
        Console.WriteLine("Counter 1 started");

        Continue();
    }

    public override void Continue()
    {
        _count++;

        Console.WriteLine($"Count = {_count}");

        if (_count >= 10)
        {
            Console.WriteLine("Counter 1 finished");
            Exit();
            return;
        }

        Yield();
    }
}