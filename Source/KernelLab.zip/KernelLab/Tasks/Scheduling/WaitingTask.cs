﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Scheduling;

public sealed class WaitingTask : BaseTask
{
    private bool _wokenUp;

    public WaitingTask() : base("WAITER", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("WAITER waiting");

        Wait();
    }

    public override void Continue()
    {
        if (!_wokenUp)
        {
            _wokenUp = true;

            Console.WriteLine("WAITER resumed");

            Exit();

            return;
        }

        Wait();
    }
}