﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Scheduling;

public sealed class TransitionTask : BaseTask
{
    public TransitionTask() : base("TRANSITION", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("TRANSITION started");

        Wait();
    }

    public override void Continue()
    {
        Console.WriteLine("TRANSITION resumed");

        Exit();
    }
}