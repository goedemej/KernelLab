﻿using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Scheduling;

public sealed class BlockingTask : BaseTask
{
    public BlockingTask() : base("CLIENT", priority: 10)
    {
    }

    public override void Execute()
    {
        Console.WriteLine("CLIENT blocking");

        Wait();
    }

    public override void Continue()
    {
        Console.WriteLine("CLIENT resumed");

        Exit();
    }
}
