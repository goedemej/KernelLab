﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Scheduling;

public sealed class SignalerTask : BaseTask
{
    private readonly string _targetTaskId;

    public SignalerTask(string targetTaskId) : base("SIGNALER", priority: 10)
    {
        _targetTaskId = targetTaskId;
    }

    public override void Execute()
    {
        BaseTask? task = Kernel.Kernel.Tasks.Find(_targetTaskId);

        if (task != null)
        {
            Console.WriteLine($"Waking {_targetTaskId}");

            Scheduler.MakeReady(task);
        }

        Exit();
    }

    public override void Continue()
    {
    }
}