﻿using KernelLab.Kernel;
using KernelLab.Tasks.Core;


namespace KernelLab.Tasks.Scheduling;

public sealed class WorkerTask : BaseTask
{
    private readonly string _targetTaskId;

    public WorkerTask(string targetTaskId) : base("WORKER", priority: 10)
    {
        _targetTaskId = targetTaskId;
    }

    public override void Execute()
    {
        Console.WriteLine("WORKER processing");

        BaseTask? task =
           Kernel.Kernel.Tasks.Find(_targetTaskId);

        if (task != null)
        {
            Console.WriteLine($"Waking {_targetTaskId}");

            Scheduler.MakeReady(task);
        }

        Exit();
    }

    public override void Continue()
    {
    }
}
