﻿namespace KernelLab.Tasks.Core;

public sealed class SentinelTask : BaseTask
{
    public SentinelTask(string id)
            : base(id, registerQueue: false)
    {
    }

    public override void Execute()
    {
        throw new InvalidOperationException(
        "Sentinel tasks cannot be executed.");
    }

    public override void Continue()
    {
        throw new InvalidOperationException(
        "Sentinel tasks cannot be continued.");
    }
}
