﻿using KernelLab.Diagnostics;
using KernelLab.Kernel;
using KernelLab.Messaging;
using KernelLab.States;

namespace KernelLab.Tasks.Core;

public abstract class BaseTask
{
    public bool Started { get; set; }

    public string TaskId { get; set; }

    public int Priority { get; set; }

    public TaskState State { get; set; }

    public BaseTask? Prev { get; set; }

    public BaseTask? Next { get; set; }

    public MessageQueue Messages { get; } = new();

    protected BaseTask(
        string taskId,
        int priority = 0,
        bool registerQueue = true)
    {
        TaskId = taskId;
        Priority = priority;
        State = TaskState.New;

        if (registerQueue)
            InitializeMessaging();
    }

    private void InitializeMessaging()
    {
        Kernel.Kernel.Bus.RegisterQueue(TaskId, Messages);

        Messages.OnMessageArrived += OnMessageArrived;
    }

    private void OnMessageArrived()
    {
        if (State != TaskState.Running &&
        State != TaskState.Ready &&
        State != TaskState.Terminated)
        {
            Scheduler.MakeReady(this);
        }
    }

    public Message CreateMessage(
        string targetId,
        MessageType type,
        object? payload,
        MessagePriority priority = MessagePriority.Normal)
    {
        Message msg = MessagePool.Rent();

        msg.SenderId = TaskId;
        msg.TargetId = targetId;
        msg.Type = type;
        msg.Priority = priority;
        msg.Payload = payload;

        return msg;
    }

    public void Send(Message message)
    {
        Kernel.Kernel.Bus.Post(message);

        KernelTrace.Write(
            TraceType.MessageSend,
            message.SenderId,
            message.TargetId,
            message.Type.ToString());
    }

    public void SendAndWait(Message message)
    {
        Kernel.Kernel.Bus.Post(message);

        KernelTrace.Write(
           TraceType.MessageSend,
           message.SenderId,
           message.TargetId,
           message.Type.ToString());

        Wait();
    }

    public void Reply(
        Message request,
        MessageType type,
        object? payload)
    {
        Message reply = MessagePool.Rent();

        reply.SenderId = TaskId;
        reply.TargetId = request.SenderId;
        reply.Type = type;
        reply.Payload = payload;

        Kernel.Kernel.Bus.Post(reply);

        KernelTrace.Write(
            TraceType.MessageReply,
            reply.SenderId,
            reply.TargetId,
            reply.Type.ToString());
    }

    public void Reply(
        Message request,
        object? payload)
    {
        Reply(
        request,
        MessageType.Response,
        payload);
    }

    public Message? Receive()
    {
        Message? message = Messages.Dequeue();

        if (message != null)
        {
            KernelTrace.Write(
                TraceType.MessageReceive,
                TaskId,
                message.SenderId,
                message.Type.ToString());
        }

        return message;
    }

    public void Wait()
    {
        Scheduler.WaitCurrent();
    }

    public void Yield()
    {
        Scheduler.Yield();
    }

    public void Exit()
    {
        Scheduler.ExitCurrent();
    }

    public abstract void Execute();

    public abstract void Continue();
}
 