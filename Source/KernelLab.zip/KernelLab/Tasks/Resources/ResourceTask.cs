﻿using KernelLab.Resources;
using KernelLab.Tasks.Core;

namespace KernelLab.Tasks.Resources;

public sealed class ResourceTask : BaseTask
{
    private string? _resource;

    public ResourceTask(string taskId) : base(taskId, priority: 10)
    {
    }

    public override void Execute()
    {
        Continue();
    }

    public override void Continue()
    {
        if (_resource == null)
        {
            _resource = ResourceStore.Pool.Allocate(this);

            if (_resource == null)
            {
                Console.WriteLine($"{TaskId} waiting for resource");

                Wait();

                return;
            }

            Console.WriteLine(
                $"{TaskId} allocated {_resource}");

            Yield();

            return;
        }

        Console.WriteLine($"{TaskId} releasing {_resource}");

        ResourceStore.Pool.Release(_resource);

        Exit();
    }
}