﻿namespace KernelLab.Messaging;

/// <summary>
/// Reusable message object pool.
/// Reduces allocations by recycling Message instances.
/// </summary>
public static class MessagePool
{
    private const string MessagePrefix = "message_";

    private static Stack<Message> _messages = null!;
    private static int _nextIndex;

    internal static void Init(int initialSize)
    {
        _messages = new Stack<Message>(initialSize);

        for (int i = 0; i < initialSize; i++)
            _messages.Push(CreateMessage());

        _nextIndex = initialSize;
    }

    /// <summary>
    /// Obtains a message from the pool.
    /// Automatically grows the pool if required.
    /// </summary>
    public static Message Rent()
    {
        if (_messages.Count == 0)
            _messages.Push(CreateMessage());

        Message message = _messages.Pop();

        Reset(message);

        return message;
    }

    /// <summary>
    /// Returns a message to the pool.
    /// </summary>
    public static void Return(Message message)
    {
        Reset(message);

        _messages.Push(message);
    }

    private static Message CreateMessage()
    {
        return new Message
        {
            Id = $"{MessagePrefix}{_nextIndex++}",
            SenderId = string.Empty,
            TargetId = string.Empty,
            Type = MessageType.Unknown,
            Payload = null
        };
    }

    private static void Reset(Message message)
    {
        message.SenderId = string.Empty;
        message.TargetId = string.Empty;
        message.Type = MessageType.Unknown;
        message.Payload = null;
    }
}
