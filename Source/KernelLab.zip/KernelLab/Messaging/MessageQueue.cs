﻿namespace KernelLab.Messaging;

public sealed class MessageQueue
{
    private readonly LinkedList<Message> _messages = new();

    public event Action? OnMessageArrived;

    public int Count => _messages.Count;

    public void Enqueue(Message message)
    {
        LinkedListNode<Message>? current = _messages.First;

        // Zoek het eerste bericht met LAGERE prioriteit.
        while (current != null &&
        current.Value.Priority >= message.Priority)
        {
            current = current.Next;
        }

        if (current == null)
        {
            _messages.AddLast(message);
        }
        else
        {
            _messages.AddBefore(current, message);
        }

        OnMessageArrived?.Invoke();
    }

    public Message? Dequeue()
    {
        if (_messages.Count == 0)
            return null;

        Message message = _messages.First!.Value;

        _messages.RemoveFirst();

        return message;
    }

    public Message? Peek()
    {
        return _messages.Count == 0
        ? null
        : _messages.First!.Value;
    }
}