﻿namespace KernelLab.Messaging;

public enum MessageType
{
    Unknown = 0,

    Request,
    Response,

    Event,
    Notification,

    Start,
    Stop,

    Complete,

    Error
}