﻿namespace KernelLab.Messaging;

public class Message
{
    public string Id { get; set; } = string.Empty;

    public string SenderId { get; set; } = string.Empty;

    public string TargetId { get; set; } = string.Empty;

    public MessageType Type { get; set; }

    public MessagePriority Priority { get; set; } = MessagePriority.Normal;

    public object? Payload { get; set; }
}