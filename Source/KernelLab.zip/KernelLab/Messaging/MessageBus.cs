﻿namespace KernelLab.Messaging;

/// <summary>
/// Central message router.
/// </summary>
public sealed class MessageBus
{
    private readonly Dictionary<string, MessageQueue> _queues = new();

    /// <summary>
    /// Registers a task's message queue.
    /// </summary>
    public void RegisterQueue(
        string taskId,
        MessageQueue queue)
    {
        _queues[taskId] = queue;
    }

    /// <summary>
    /// Unregisters a task's message queue.
    /// </summary>
    public void UnregisterQueue(string taskId)
    {
        _queues.Remove(taskId);
    }

    /// <summary>
    /// Posts a message to its destination queue.
    /// </summary>
    public void Post(Message message)
    {
        if (!_queues.TryGetValue(
        message.TargetId,
        out MessageQueue? queue))
        {
            MessagePool.Return(message);
            return;
        }

        queue.Enqueue(message);
    }

    /// <summary>
    /// Determines whether a task is registered.
    /// </summary>
    public bool Contains(string taskId)
    {
        return _queues.ContainsKey(taskId);
    }

    /// <summary>
    /// Number of registered queues.
    /// </summary>
    public int Count => _queues.Count;
}
