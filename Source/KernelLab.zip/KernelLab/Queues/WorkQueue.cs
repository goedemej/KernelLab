﻿namespace KernelLab.Queues;

public static class WorkQueue
{
    private static readonly Queue<string> _queue = new();

    public static void Enqueue(string job)
    {
        _queue.Enqueue(job);
    }

    public static bool TryDequeue(out string job)
    {
        if (_queue.Count == 0)
        {
            job = string.Empty;

            return false;
        }

        job = _queue.Dequeue();

        return true;
    }
}