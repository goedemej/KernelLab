﻿using KernelLab.Synchronization;

namespace KernelLab.Queues;

public static class ProducerConsumerSemaphore
{
    public static readonly BinarySemaphore Signal = new();
}
