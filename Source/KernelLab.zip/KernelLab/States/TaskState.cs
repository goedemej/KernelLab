﻿namespace KernelLab.States;

public enum TaskState
{
    New,
    Ready,
    Running,
    Waiting,
    Blocked,
    Terminated
}